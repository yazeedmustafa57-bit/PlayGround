'use strict';

// Victor KI-Telefonassistent – Express + WebSocket-Server.
// - Statische Bestandsseiten + Dashboard
// - Diagnose: /health, /api/elevenlabs/status, /api/twilio/status, /api/settings, /api/llm/status
// - Chat-Steuerung: POST /api/chat/instruct, POST /api/call/start, GET /api/calls, GET /api/call/:id/transcript
// - Twilio-Voice-Webhooks: POST /voice/outgoing, POST /voice/incoming, POST /voice/status (TwiML)
// - WebSockets: /media-stream (Twilio ulaw_8000), /dashboard-stream (Live-Transkript)
// Alles ohne Secrets in Antworten/Logs. Ohne Credentials: simulierter Modus.

try { require('dotenv').config(); } catch { /* dotenv optional */ }

const http = require('node:http');
const path = require('node:path');
const express = require('express');

const { createInitialState, processUserMessage } = require('./call-controller');
const { sanitizeState } = require('./personal-data-policy');
const { getPublicStatus } = require('./elevenlabs-config');
const { getTwilioPublicStatus } = require('./twilio-config');
const { getPublicSettings, getAppConfig } = require('./app-config');
const orchestrator = require('./outbound-orchestrator');
const { buildOutboundTwiml, buildIntroSayText } = require('./twilio-voice');
const { parseStreamMessage, extractAudioPayload } = require('./twilio-media');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
};

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    next();
  });
  app.use(express.json({ limit: '256kb' }));
  app.use(express.urlencoded({ extended: false }));

  // ---- Diagnose (Bestand, secret-frei) ----
  app.get('/health', (req, res) => res.json({ ok: true, service: 'victor-ai-assistant' }));
  app.get('/api/elevenlabs/status', (req, res) => res.json(getPublicStatus()));
  app.get('/api/twilio/status', (req, res) => res.json(getTwilioPublicStatus()));
  app.get('/api/settings', (req, res) => res.json({ ok: true, settings: getPublicSettings() }));
  app.get('/api/llm/status', (req, res) => {
    // Kein externes LLM: Dialog = ElevenLabs Conversational AI Agent.
    res.json({ ok: true, configured: false, model: 'elevenlabs-agent', mode: 'elevenlabs-conversational-ai' });
  });
  app.get('/api/calls', (req, res) => res.json({ ok: true, calls: orchestrator.listSessions() }));
  app.get('/api/call/:id/transcript', (req, res) => {
    const s = orchestrator.getSession(req.params.id);
    if (!s) return res.status(404).json({ ok: false, error: 'Unknown call id' });
    return res.json({ ok: true, id: s.id, transcript: s.transcript });
  });

  // ---- Bestand: lokale Auftragserkennung ----
  app.post('/api/test/message', (req, res) => {
    const text = typeof req.body?.text === 'string' ? req.body.text : '';
    const incoming = req.body?.state && typeof req.body.state === 'object'
      ? req.body.state
      : createInitialState();
    const { state } = processUserMessage(incoming, text);
    const clean = sanitizeState(state);
    res.json({
      ok: true,
      purpose: clean.purpose,
      message: clean.message,
      contactName: clean.contactName,
      phoneNumber: clean.phoneNumber,
      requestedDate: clean.requestedDate,
      requestedTime: clean.requestedTime,
      callerName: clean.callerName,
      collectionMode: clean.collectionMode,
      state: clean,
    });
  });

  // ---- Neu: Chat-Anweisung verstehen (Schritt 1–2, kein Anruf) ----
  app.post('/api/chat/instruct', async (req, res) => {
    try {
      const instruction = String(req.body?.instruction || req.body?.text || '');
      if (!instruction.trim()) return res.status(400).json({ ok: false, error: 'Missing instruction' });
      const plan = await orchestrator.instruct(instruction);
      res.json(plan);
    } catch (err) {
      res.status(500).json({ ok: false, error: 'instruct failed' });
    }
  });

  // ---- Neu: Anruf starten (Schritt 3, Twilio oder Simulation) ----
  app.post('/api/call/start', async (req, res) => {
    try {
      const { instruction, to, contactName, goal } = req.body || {};
      const text = String(instruction || goal || '');
      if (!text.trim() && !to) return res.status(400).json({ ok: false, error: 'Missing instruction or to' });
      const session = await orchestrator.startCall({ instruction: text, to, contactName, goal });
      res.json({ ok: true, call: session });
    } catch (err) {
      if (err && err.code === 'MISSING_TO') return res.status(400).json({ ok: false, error: String(err.message) });
      res.status(500).json({ ok: false, error: 'call start failed' });
    }
  });

  // ---- Twilio Voice-Webhooks (TwiML) ----
  const twiml = (xml, res) => res.type('text/xml').send(xml);
  app.post('/voice/outgoing', (req, res) => {
    const appCfg = getAppConfig();
    const xml = buildOutboundTwiml({
      agentName: appCfg.agentName,
      contactName: req.body?.contactName || undefined,
      publicBaseUrl: appCfg.publicBaseUrl,
    });
    twiml(xml, res);
  });
  app.post('/voice/incoming', (req, res) => {
    const appCfg = getAppConfig();
    const xml = buildOutboundTwiml({ agentName: appCfg.agentName, publicBaseUrl: appCfg.publicBaseUrl });
    twiml(xml, res);
  });
  app.post('/voice/status', (req, res) => res.json({ ok: true }));

  // ---- Bestandsseiten (saubere URLs) ----
  const pages = {
    '/': 'index.html',
    '/chat': 'chat.html',
    '/eleven-chat': 'eleven-chat.html',
    '/call': 'call.html',
    '/journal': 'journal.html',
    '/setup': 'setup.html',
    '/dashboard': 'dashboard.html',
  };
  for (const [route, file] of Object.entries(pages)) {
    app.get(route, (req, res) => res.sendFile(path.join(PUBLIC_DIR, file)));
  }
  app.use(express.static(PUBLIC_DIR));

  // ---- 404 + Fehler ----
  // GET-only-Routen mit falscher Methode -> 405 (Bestandskompatibilität).
  const GET_ONLY = new Set(['/health', '/api/elevenlabs/status', '/api/twilio/status', '/api/settings', '/api/llm/status', '/api/calls']);
  app.use((req, res, next) => {
    const p = req.path;
    if ((GET_ONLY.has(p) || /^\/api\/call\/[^/]+\/transcript$/.test(p)) && req.method !== 'GET') {
      return res.status(405).json({ ok: false, error: 'Method Not Allowed' });
    }
    next();
  });
  app.use((req, res) => {
    if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false, error: 'Not Found' });
    return res.status(404).json({ ok: false, error: 'Not Found' });
  });
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err && err.type === 'entity.parse.failed') {
      return res.status(400).json({ ok: false, error: 'Invalid JSON body' });
    }
    return res.status(500).json({ ok: false, error: 'Internal error' });
  });
  return app;
}

function attachWebSockets(server) {
  let WSS;
  try {
    // eslint-disable-next-line global-require
    WSS = require('ws').WebSocketServer;
  } catch {
    return null;
  }
  const wss = new WSS({ noServer: true });
  server.on('upgrade', (req, socket, head) => {
    const url = String(req.url || '').split('?')[0];
    if (url === '/media-stream' || url === '/dashboard-stream') {
      wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
    } else {
      socket.destroy();
    }
  });
  wss.on('connection', (ws, req) => {
    const url = String(req.url || '').split('?')[0];
    if (url === '/dashboard-stream') {
      orchestrator.dashboardSockets.add(ws);
      ws.on('close', () => orchestrator.dashboardSockets.delete(ws));
      try { ws.send(JSON.stringify({ type: 'hello', calls: orchestrator.listSessions() })); } catch { /* ignore */ }
      return;
    }
    // /media-stream: Twilio sendet {event, media:{payload}} (ulaw_8000 base64).
    // Minimal-Pipeline: Transkript-Stub + Echo, echte STT/LLM/TTS-Kopplung
    // erfolgt über orchestrator.handleCallerUtterance (Adapter injizierbar).
    let streamSid = null;
    let callId = null;
    try {
      const q = new URL(String(req.url || '/'), 'http://localhost').searchParams;
      callId = q.get('callId');
    } catch { /* ignore */ }
    ws.on('message', async (data) => {
      let msg;
      try { msg = parseStreamMessage(String(data)); } catch { return; }
      if (msg.event === 'start') {
        streamSid = (msg.start && msg.start.streamSid) || msg.streamSid || null;
        return;
      }
      if (msg.event === 'media') {
        let payload;
        try { payload = extractAudioPayload(msg); } catch { return; }
        if (!payload) return;
        // In dieser Stufe: kein echtes STT ohne Key – nur Durchreichung.
        // Bei konfiguriertem Stack übernimmt der Live-Betrieb hier
        // Scribe→LLM→Flash; das Dashboard sieht Status über /dashboard-stream.
        if (callId && orchestrator.getSession(callId)) {
          // Platz für echte Pipeline; aktuell kein Fake-Transkript.
        }
        return;
      }
      if (msg.event === 'stop') {
        try { ws.close(); } catch { /* ignore */ }
      }
    });
    // Begrüßungs-Mark (kein Audio-Fake): Twilio spielt TwiML-<Say> bereits ab.
    void streamSid;
  });
  return wss;
}

function createServer() {
  const app = createApp();
  const server = http.createServer(app);
  attachWebSockets(server);
  return server;
}

function getPort() {
  const parsed = Number.parseInt(process.env.PORT || '5051', 10);
  return Number.isSafeInteger(parsed) ? parsed : 5051;
}

if (require.main === module) {
  const server = createServer();
  const port = getPort();
  server.listen(port, () => {
    console.log(`victor-ai-assistant listening on http://localhost:${port}`);
    console.log(`Dashboard: http://localhost:${port}/dashboard`);
  });
}

module.exports = { createServer, createApp, attachWebSockets, getPort, requestHandler: createApp() };
