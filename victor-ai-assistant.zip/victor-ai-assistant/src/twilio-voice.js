'use strict';

// Twilio Voice: ausgehende Anrufe + TwiML für Media Streams.
// - startOutboundCall(): nur mit Credentials, sonst MOCK-Modus (kein Netz).
// - TwiML-Builder: Begrüßung als KI-Assistent + <Stream> zum Backend.
// Twilio-SDK wird lazy geladen, damit Tests ohne Netz/SDK-Creds laufen.

const { getTwilioConfig, isTwilioConfigured } = require('./twilio-config');
const { getAppConfig } = require('./app-config');
const { buildVoiceTwiml } = require('./twilio-media');

function escapeXml(s) {
  return String(s || '').replace(/[<>&'"]/g, (c) => ({
    '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;',
  }[c]));
}

// Standard-Begrüßung: stellt sich als KI-Assistent vor (Pflicht laut Spec).
function buildIntroSayText({ agentName, contactName }) {
  const name = agentName || 'Victor';
  const who = contactName ? ` ${contactName}` : '';
  return `Hallo${who}, hier ist ${name}, Ihr KI-Assistent.`;
}

function mediaStreamUrl(publicBaseUrl) {
  const base = String(publicBaseUrl || '').replace(/\/$/, '');
  if (!base) return '';
  return base.replace(/^http/, 'ws') + '/media-stream';
}

// TwiML für ausgehende Anrufe: Intro-Say + bidirektionaler Media Stream.
function buildOutboundTwiml({ agentName, contactName, publicBaseUrl, extraSay } = {}) {
  const say = escapeXml(extraSay || buildIntroSayText({ agentName, contactName }));
  const streamUrl = mediaStreamUrl(publicBaseUrl);
  const streamPart = streamUrl
    ? `    <Stream url="${escapeXml(streamUrl)}" />`
    : '    <!-- PUBLIC_BASE_URL fehlt: Media Stream inaktiv -->';
  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<Response>',
    `  <Say language="de-DE">${say}</Say>`,
    '  <Connect>',
    streamPart,
    '  </Connect>',
    '</Response>',
  ].join('\n');
}

// Startet einen ausgehenden Anruf. Ohne Credentials: simuliertes Ergebnis
// (simulated:true), KEIN Netz. Mit Credentials: echte Twilio-REST-Nutzung.
async function startOutboundCall({ to, twimlUrl, statusCallbackUrl, client } = {}) {
  const cfg = getTwilioConfig();
  const app = getAppConfig();
  if (!to || typeof to !== 'string') {
    const err = new Error('Missing target number "to"');
    err.code = 'MISSING_TO';
    throw err;
  }
  if (!isTwilioConfigured()) {
    return {
      ok: true,
      simulated: true,
      sid: `MOCK-${Date.now()}`,
      to,
      from: cfg.phoneNumber || 'unconfigured',
      note: 'Twilio nicht konfiguriert – simulierter Anruf, kein Netz.',
    };
  }
  const twilioClient = client || (() => {
    // eslint-disable-next-line global-require
    const twilio = require('twilio');
    return twilio(cfg.accountSid, cfg.authToken);
  })();
  const base = String(app.publicBaseUrl || '').replace(/\/$/, '');
  const call = await twilioClient.calls.create({
    to,
    from: cfg.phoneNumber,
    url: twimlUrl || `${base}/voice/outgoing`,
    statusCallback: statusCallbackUrl || `${base}/voice/status`,
    statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
    statusCallbackMethod: 'POST',
  });
  return { ok: true, simulated: false, sid: call.sid, to, from: cfg.phoneNumber };
}

module.exports = {
  buildIntroSayText,
  buildOutboundTwiml,
  startOutboundCall,
  mediaStreamUrl,
  buildVoiceTwiml,
};
